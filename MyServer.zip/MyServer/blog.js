const express = require('express');
const path = require('path');
const mysql = require('mysql2');

const router = express.Router();

const conexao = mysql.createConnection({

    host: 'localhost',

    user: 'root',

    password: '',

    database: 'blogdb'

});

// abrir blog
router.get('/blog', (req, res) => {

    const sql = 'SELECT * FROM posts';

    conexao.query(sql, (erro, resultados) => {

        if(erro){
            console.log(erro);
        }
        else{

            res.render('blog', {
                posts: resultados
            });

        }

    });

});

// abrir cadastro post
router.get('/cadastrar_post', (req, res) => {

    res.sendFile(path.join(__dirname,
    'public/html/cadastrar_post.html'));

});

// cadastrar post
router.post('/cadastrar_post', (req, res) => {

    const titulo = req.body.titulo;
    const resumo = req.body.resumo;
    const conteudo = req.body.conteudo;

    const sql = `
        INSERT INTO posts
        (titulo, resumo, conteudo)
        VALUES (?, ?, ?)
    `;

    conexao.query(sql,
        [titulo, resumo, conteudo],

        (erro) => {

            if(erro){
                console.log(erro);
            }
            else{
                res.redirect('/blog');
            }

        }

    );

});

module.exports = router;