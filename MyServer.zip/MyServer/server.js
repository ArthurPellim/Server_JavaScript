const express = require('express');
const path = require('path');

const app = express();

const blogRoutes = require('./blog');

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

// importar blog
app.use(blogRoutes);

// rota principal
app.get('/', (req, res) => {

    res.sendFile(path.join(__dirname,
    'public/html/Projects.html'));

});

app.listen(80, '0.0.0.0', () => {

    console.log('Servidor rodando');

});